#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Contain {
  int qty;
  char nama[255];
  int exp;
  char jenis[255];
  Contain *next, *prev;
};

struct Group {
  char grup[255];
  Contain *head_contain, *tail_contain;
  Group *next;
}*head_group, *tail_group;



Group *createGroup(const char *nama){
  Group *temp = (Group*)malloc(sizeof(Group));
  strcpy(temp->grup, nama);
  temp->next = NULL;
  temp->head_contain =temp->tail_contain = NULL;
  return temp;
};

Contain *createIsi(const char *nama, const char *jenis, int qty, int exp) {
  Contain *temp = (Contain*)malloc(sizeof(Contain));
  strcpy(temp->nama, nama);
  strcpy(temp->jenis, jenis);
  temp->qty = qty;
  temp->exp = exp;
  temp->next =temp->prev =  NULL;

  return temp;
};


void pushGroup(const char *nama) {
  Group *temp = createGroup(nama);
  if(!head_group) {
    head_group = tail_group = temp;
  }else {
    tail_group->next = temp;
    tail_group = temp;
  }
}

void pushIsi(Group *root, const char *nama, const char *jenis, int qty, int exp) {
  Contain *temp = createIsi(nama, jenis, qty, exp);
  if(!root->head_contain) {
    root->head_contain = root->tail_contain = temp;
  } else if(strcmp(nama, root->head_contain->nama ) <0){
    temp->next = root->head_contain;
    root->head_contain->prev = temp;
    root->head_contain = temp;
  }else if(strcmp(nama, root->head_contain->nama )>0){
    temp->prev = root->tail_contain;
    root->tail_contain->next = temp;
    root->tail_contain = temp;
  }else {
    Contain *curr = root->head_contain;
    while(strcmp(nama, curr->nama) > 0){
      curr = curr->next;
    }
    temp->prev = curr->prev;
    temp->next = curr;
    temp->prev->next = temp;
    curr->prev = temp;
  }
}

Group *cariRoot(const char *name) {
  Group *curr = head_group;
  while(curr){
    if(strcmp(curr->grup, name) == 0){
      break;
    }
    curr = curr->next;
  }

  return curr;
}

void popHead_isi(Group *root) {
  if(!root->head_contain){
    return;
  }else if(root->head_contain == root->tail_contain){
    root->head_contain = root->tail_contain = NULL;
  }else {
    Contain *temp = root->head_contain->next; // buat angka setelah head itu temp;
    root->head_contain->next = temp->prev = NULL; // jadi NULL < 18 > N || NULL
    root->head_contain = NULL;
    free(root->head_contain);
    root->head_contain = temp;
  }
}

void popTail_isi(Group *root){
  if(!root->head_contain){
    return;
  }else if(root->head_contain == root->tail_contain){
    root->head_contain = root->tail_contain = NULL;
    free(root->head_contain);
  }else {
    Contain *temp = root->tail_contain->prev; // buat angka sebelum tail itu temp
    root->tail_contain->prev = temp->next = NULL; // tail kanan, temp kiri = NULL, putus hubungan
    root->tail_contain = NULL; // tail dijadikan null
    free(root->tail_contain); // free tail
    root->tail_contain = temp;
  }
}


void removeIsi(Group *root, const char *name) {
  if(!root->head_contain){
    return;
  }else if(strcmp(name, root->head_contain->nama) == 0){
    popHead_isi(root);
  }else if(strcmp(name, root->tail_contain->nama) == 0){
    popTail_isi(root);
  }else {
    Contain *curr = root->head_contain;
    while(curr != NULL && strcmp(name, curr->nama) !=0) {
      curr = curr->next;
    }

    if(!curr){
      puts("The item you wish to delete is not present at the moment");
      return;
    }

    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    curr->next = curr->prev = NULL;
    curr = NULL;
    free(curr);
  }
} 

void addGroup(){
    printf("Please add the name of the group you want to insert:");
    char asing[255] ="";
    getchar();
    scanf("%[^\n]", asing);
    Group *node = cariRoot(asing);
    if(node){
      puts("Sorry, this group name is already in the list.");
      addGroup();
    }else {
      pushGroup(asing);
      printf("You have added the group %s!\n", asing);
      puts("Please continue.");
    }
  
  return;

}

void addRemoveList() {
  puts("Would you like to add or remove something on your list?");
  printf("1. Add\n2. Remove\n3. Add Group\n4. Exit\n");
  printf("Please input your choice:");
  int scan = 0;
  scanf("%d", &scan);
  if(scan == 1) {
    
    // cari group
    Group *node = NULL;
    do{
      printf("Please input group name:");      
      char group[255] = "";
      getchar();
      scanf("%[^\n]", group);
      Group *nod = cariRoot(group);
      node = nod;
    }while(!node);
  
  
    // input name
    printf("Please input item name:");
    char asing[255] = "";
    getchar();
    scanf("%[^\n]", asing);

    //cari qty
    printf("Please input item qty:");
    int qty = 0;
    scanf("%d", &qty);

    // cari jenis
    printf("1. gal.\n2. oz.\n3. tbs.\n4. pcs.\n");
    printf("Please input item type:");
    int scan2 = 0;
    scanf("%d", &scan2);

   char type[255] = "";
    if(scan2 == 1){
      strcpy(type, "gal.");
    }else if(scan2 == 2) {
      strcpy(type, "oz.");
    }else if(scan2 == 3) {
      strcpy(type, "tbs.");
    }else if(scan2 == 4) {
      strcpy(type, "pcs.");
    }else {
      printf("Input invalid, please try again.\n");
      addRemoveList();
    }

    int exp = 0;
    printf("How many days will this item last?\n");
    printf("Input:");
    scanf("%d", &exp);

    pushIsi(node, asing, type, qty, exp);
  }else if(scan == 2) {
    // cari group
    Group *node = NULL;
    do{
      printf("Please input group name you wish to delete:");      
      char asing[255] = "";
      getchar();
      scanf("%[^\n]", asing);
      Group *nod = cariRoot(asing);
      node = nod;
    }while(!node);

    char asing[255] = "";
    printf("Please input item name you wish to delete:");
    getchar();
    scanf("%[^\n]", asing);
    
    removeIsi(node, asing);
  }else if(scan == 4){
    return;
  }else if(scan == 3){
    addGroup();
  }else{
    puts("Sorry, your input is invalid");
    addRemoveList();
  }

return;
}


void Pantry() {
  Group *curr = head_group;
  puts("Your Pantry List");
  int z = 1;
  while(curr) {
    printf("%d. %s\n", z, curr->grup);
    puts("------------------------------");
    z++;
    Contain *curr2 = curr->head_contain;
    int j = 1;
      printf("\tNo. Name      Qty  Type (Expire in)\n");  
      if(!curr2){
        puts("\tThere is no item at this group");
      }  
    while(curr2) {

      printf("\t%d.  %-10s %-3d %-4s %d day(s)",j,  curr2->nama, curr2->qty, curr2->jenis, curr2->exp);
      j++;
      if(curr2->exp <= 7){
        puts("(near expired)");
      }else {
        puts("");
      }
      curr2 = curr2->next;
    }
    puts("=============================");
    curr = curr->next;
  }

  addRemoveList();
  printf("Would you like to continue?\n1. Yes\n2. No\n");
  int a = 0;
  scanf("%d", &a);
  if(a == 1){
    Pantry();
  }else {
    return;
  }
}

int main(){
  pushGroup("Dairy");
  pushGroup("Fruits");
  pushGroup("Meats");
  Pantry();
  puts("Thank you for using this app!");
  return 0;
}