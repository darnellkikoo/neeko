CREATE DATABASE Assignment1
USE Assignment1

CREATE TABLE Users(
	UserId CHAR(5),
	LastName VARCHAR(255),
	FirstName VARCHAR(255) NOT NULL,
	School VARCHAR(255),
	UserAddress VARCHAR(255),
	Email VARCHAR(255) NOT NULL,
	PhoneNumber CHAR(12) NOT NULL,
	UserLocation VARCHAR(255),
	DateofBirth VARCHAR(255),
	Gender CHAR(1) NOT NULL,

	CONSTRAINT checkEmail
		CHECK(Email like '%a%'),
	CONSTRAINT UsersPK PRIMARY KEY (UserId)
)


CREATE TABLE Pages(
	PageId char(25),
	PageName varchar(255) not null,
	PageContent varchar(255) not null,

	constraint PagesPK PRIMARY KEY (PageId)
)

CREATE TABLE PageLikes(
	PageId char(25),
	UserId char(5),

	CONSTRAINT PageLikesPK PRIMARY KEY (PageId),
	CONSTRAINT PagesFK FOREIGN KEY (PageId) REFERENCES Pages(PageId)
		ON UPDATE CASCADE ON DELETE NO ACTION,
	CONSTRAINT UsersFK FOREIGN KEY (UserId) REFERENCES
		Users(UserId)
		ON UPDATE CASCADE ON DELETE NO ACTION
)

CREATE TABLE Friends(
	FriendId char(25),
	UserId char(5),

	CONSTRAINT FriendsPK PRIMARY KEY (FriendId),
	CONSTRAINT FriendsUsersFK Foreign key (UserId) REFERENCES
	Users(UserId)
	ON UPDATE CASCADE ON DELETE NO ACTION
)

CREATE TABLE Posts(
	UserId char(5),
	PostId char(25),
	PostDate char(25) not null,
	PostContent varchar(255) not null,

	CONSTRAINT PostsPK PRIMARY KEY(PostId),
	CONSTRAINT PostsFK FOREIGN KEY (UserId) REFERENCES Users(UserId)
		ON UPDATE CASCADE ON DELETE NO ACTION,

)

CREATE TABLE Comments(
	CommentId char(25),
	UserId Char(5),
	PostId char(25),
	CommentContent varchar(255) not null,

	constraint CommentsPk PRIMARY KEY (CommentId),
	CONSTRAINT CommentsFKUserId FOREIGN KEY (UserId) REFERENCES	Users(UserId)
		ON UPDATE CASCADE ON DELETE NO ACTION,
	CONSTRAINT CommentsFKPostId FOREIGN KEY (PostId) REFERENCES Posts(PostId)
		ON UPDATE NO ACTION ON DELETE NO ACTION
)

CREATE TABLE CommentLikes(
	CommentId char(25),
	UserId char(5),
	CONSTRAINT CommentLikesPK PRIMARY KEY (UserId),
	CONSTRAINT CommentLikesFK1 FOREIGN KEY (CommentId) REFERENCES Comments(CommentId)
		ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT CommentLikesFK2 FOREIGN KEY (UserId) REFERENCES Users(UserId)
		ON UPDATE CASCADE ON DELETE NO ACTION

)

CREATE TABLE PostLikes(
	PostId char(25),
	UserId char(5),

	CONSTRAINT PostLikesPK PRIMARY KEY (PostId, UserId),
	CONSTRAINT PostLikesFK1 FOREIGN KEY (PostId) REFERENCES Posts(PostId)
		ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT PostLikesFK2 FOREIGN KEY (UserId) REFERENCES Users(UserId)
		ON UPDATE CASCADE ON DELETE NO ACTION
)

CREATE TABLE Shares(
	UserId char(5),
	PostId char(25),
	PostDate varchar(255) not null,
	PostContent varchar(255) not null,

	CONSTRAINT SharesPK PRIMARY KEY (UserId, PostId),
	CONSTRAINT SharesFK1 FOREIGN KEY (UserId) REFERENCES Users(UserId)
		ON UPDATE CASCADE ON DELETE NO ACTION,
	CONSTRAINT SharesFK2 FOREIGN KEY (PostId) REFERENCES Posts(PostId)
		on update no action on delete no action

)

CREATE TABLE Photos(
	PostId char(25),
	PhotoId char(25),
	ImageContent varchar(255) NOT NULL,

	CONSTRAINT PhotosPK PRIMARY KEY (PhotoId),
	CONSTRAINT PhotosFK FOREIGN KEY (PostId) REFERENCES Posts(PostId)
		ON UPDATE NO ACTION ON DELETE NO ACTION
)
/*
select * from PageLikes
select * from Pages
select * from Users
select * from Friends
select * from PostLikes
select * from Posts
select * from Comments
select * from Shares
select * from Photos
select * from CommentLikes
*/